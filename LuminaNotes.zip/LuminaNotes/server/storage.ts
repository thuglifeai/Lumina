// Lumina uses IndexedDB for client-side storage
// This file is kept for template compatibility but not actively used
// All note data is stored in the browser's IndexedDB

export interface IStorage {
  // No backend storage needed for Lumina's core features
  // Notes are stored in IndexedDB on the client
}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
