import type { Express } from "express";
import axios from "axios";

const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;

if (!DEEPSEEK_API_KEY) {
  console.warn('⚠️  DEEPSEEK_API_KEY not set in environment. AI features will be disabled.');
}

export function registerAIProxy(app: Express): void {
  // AI proxy endpoint - only active if API key is configured
  app.post('/api/ai', async (req, res) => {
    if (!DEEPSEEK_API_KEY) {
      return res.status(400).json({ 
        error: 'AI not configured',
        message: 'DEEPSEEK_API_KEY environment variable not set' 
      });
    }

    try {
      const { prompt, model = 'deepseek-coder' } = req.body;

      // Input validation
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ 
          error: 'Invalid prompt',
          message: 'Request body must include a valid "prompt" string' 
        });
      }

      // Prevent excessively long prompts (DoS protection)
      if (prompt.length > 10000) {
        return res.status(400).json({ 
          error: 'Prompt too long',
          message: 'Prompt must be less than 10,000 characters' 
        });
      }

      // Validate model parameter
      const allowedModels = ['deepseek-coder', 'deepseek-chat'];
      if (model && !allowedModels.includes(model)) {
        return res.status(400).json({ 
          error: 'Invalid model',
          message: 'Model must be one of: ' + allowedModels.join(', ')
        });
      }

      const response = await axios.post(
        DEEPSEEK_API_URL,
        {
          model,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
          max_tokens: 500,
        },
        {
          headers: {
            'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
            'Content-Type': 'application/json',
          },
          timeout: 30000, // 30 second timeout
        }
      );

      const aiText = response.data.choices?.[0]?.message?.content;
      
      if (!aiText) {
        throw new Error('No response from AI');
      }

      res.json({ result: aiText });
    } catch (error: any) {
      // Log detailed error for debugging (server-side only)
      console.error('AI Error:', {
        message: error.message,
        status: error.response?.status,
        // Don't log full response data as it may contain sensitive info
      });
      
      // Return sanitized error to client - never expose internal details
      res.status(500).json({ 
        error: 'AI request failed',
        message: 'Unable to process your request. Please try again later.'
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'Lumina is running',
      ai_enabled: !!DEEPSEEK_API_KEY,
      timestamp: Date.now(),
    });
  });
}
