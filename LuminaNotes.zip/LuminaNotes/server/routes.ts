import type { Express } from "express";
import { createServer, type Server } from "http";
import { registerAIProxy } from "./ai-proxy";

export async function registerRoutes(app: Express): Promise<Server> {
  // Lumina uses IndexedDB for note storage (client-side)
  // Backend is only used for optional AI proxy
  
  // Register AI proxy endpoints
  registerAIProxy(app);

  const httpServer = createServer(app);
  return httpServer;
}
