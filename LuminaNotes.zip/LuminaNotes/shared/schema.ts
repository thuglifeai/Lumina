import { z } from "zod";

// Note Schema - stored in IndexedDB
export interface Note {
  id: string;
  content: string; // HTML from Tiptap editor
  title: string; // Auto-extracted from content
  updatedAt: number; // Timestamp
  deletedAt?: number; // Timestamp when moved to archive
  pdf?: Blob; // Optional PDF attachment
  pptx?: Blob; // Optional PowerPoint attachment
}

export const insertNoteSchema = z.object({
  content: z.string().min(1, "Content is required"),
});

export type InsertNote = z.infer<typeof insertNoteSchema>;

// Settings Schema - stored in localStorage
export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  accentColor: string;
  fontFamily: string; // Flexible to support any font value
  fontSize: number; // in px, range: 8-72
}

export const defaultSettings: UserSettings = {
  theme: 'system',
  accentColor: '#6366f1', // Indigo by default
  fontFamily: 'inter',
  fontSize: 16,
};

// Font options - expanded library with system fonts + Google Fonts
// Each font has: key (for storage), name (display), family (CSS), category, and optional google (URL param)
export const FONT_OPTIONS = [
  // System Fonts (always available, no loading required)
  { key: 'arial', name: 'Arial', family: 'Arial, Helvetica, sans-serif', category: 'system', system: true },
  { key: 'calibri', name: 'Calibri', family: 'Calibri, "Segoe UI", system-ui, sans-serif', category: 'system', system: true },
  { key: 'times', name: 'Times New Roman', family: '"Times New Roman", Times, serif', category: 'system', system: true },
  { key: 'courier', name: 'Courier New', family: '"Courier New", Courier, monospace', category: 'system', system: true },
  { key: 'segoe', name: 'Segoe UI', family: '"Segoe UI", system-ui, sans-serif', category: 'system', system: true },
  { key: 'georgia', name: 'Georgia', family: 'Georgia, serif', category: 'system', system: true },
  { key: 'verdana', name: 'Verdana', family: 'Verdana, sans-serif', category: 'system', system: true },
  
  // Sans-serif fonts (Google Fonts)
  { key: 'inter', name: 'Inter (Clarity)', family: 'Inter, system-ui, sans-serif', category: 'sans-serif', google: 'Inter:wght@300;400;600' },
  { key: 'roboto', name: 'Roboto (Modern)', family: "'Roboto', sans-serif", category: 'sans-serif', google: 'Roboto:wght@300;400;500' },
  { key: 'opensans', name: 'Open Sans (Friendly)', family: "'Open Sans', sans-serif", category: 'sans-serif', google: 'Open+Sans:wght@300;400;600' },
  { key: 'lato', name: 'Lato (Elegant)', family: "'Lato', sans-serif", category: 'sans-serif', google: 'Lato:wght@300;400;700' },
  { key: 'montserrat', name: 'Montserrat (Bold)', family: "'Montserrat', sans-serif", category: 'sans-serif', google: 'Montserrat:wght@300;400;600' },
  { key: 'poppins', name: 'Poppins (Rounded)', family: "'Poppins', sans-serif", category: 'sans-serif', google: 'Poppins:wght@300;400;600' },
  { key: 'sourcesans', name: 'Source Sans (Clean)', family: "'Source Sans 3', sans-serif", category: 'sans-serif', google: 'Source+Sans+3:wght@300;400;600' },
  
  // Serif fonts (Google Fonts)
  { key: 'cormorant', name: 'Cormorant (Soul)', family: "'Cormorant Garamond', serif", category: 'serif', google: 'Cormorant+Garamond:wght@400;600' },
  { key: 'playfair', name: 'Playfair (Classic)', family: "'Playfair Display', serif", category: 'serif', google: 'Playfair+Display:wght@400;700' },
  { key: 'lora', name: 'Lora (Warm)', family: "'Lora', serif", category: 'serif', google: 'Lora:wght@400;600' },
  { key: 'merriweather', name: 'Merriweather (Comfort)', family: "'Merriweather', serif", category: 'serif', google: 'Merriweather:wght@300;400;700' },
  
  // Monospace fonts (Google Fonts)
  { key: 'jetbrains', name: 'JetBrains Mono (Precision)', family: "'JetBrains Mono', monospace", category: 'monospace', google: 'JetBrains+Mono:wght@300;400;600' },
  { key: 'firacode', name: 'Fira Code', family: "'Fira Code', monospace", category: 'monospace', google: 'Fira+Code:wght@300;400;500' },
  { key: 'sourcecodepro', name: 'Source Code Pro', family: "'Source Code Pro', monospace", category: 'monospace', google: 'Source+Code+Pro:wght@300;400;600' },
  
  // Script fonts (Google Fonts) - handwriting style
  { key: 'caveat', name: 'Caveat (Playful)', family: "'Caveat', cursive", category: 'script', google: 'Caveat:wght@400;700' },
  { key: 'dancing', name: 'Dancing Script (Flowing)', family: "'Dancing Script', cursive", category: 'script', google: 'Dancing+Script:wght@400;700' },
  { key: 'sacramento', name: 'Sacramento (Elegant)', family: "'Sacramento', cursive", category: 'script', google: 'Sacramento' },
  
  // Display fonts (Google Fonts) - for headings and impact
  { key: 'bebas', name: 'Bebas Neue (Impact)', family: "'Bebas Neue', display", category: 'display', google: 'Bebas+Neue' },
  { key: 'oswald', name: 'Oswald (Strong)', family: "'Oswald', sans-serif", category: 'display', google: 'Oswald:wght@300;400;600' },
] as const;

// Font size options (in pixels) - Microsoft Office style range
export const FONT_SIZE_OPTIONS = [
  { label: '8px', value: 8 },
  { label: '9px', value: 9 },
  { label: '10px', value: 10 },
  { label: '11px', value: 11 },
  { label: '12px', value: 12 },
  { label: '14px', value: 14 },
  { label: '16px (Default)', value: 16 },
  { label: '18px', value: 18 },
  { label: '20px', value: 20 },
  { label: '22px', value: 22 },
  { label: '24px', value: 24 },
  { label: '28px', value: 28 },
  { label: '32px', value: 32 },
  { label: '36px', value: 36 },
  { label: '48px', value: 48 },
  { label: '60px', value: 60 },
  { label: '72px', value: 72 },
] as const;
