import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles, RefreshCw, TrendingUp, Maximize2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AIAssistantDialogProps {
  isOpen: boolean;
  onClose: () => void;
  noteContent: string;
  onApply: (result: string) => void | Promise<void>;
}

type AIAction = 'summarize' | 'rewrite' | 'improve' | 'expand';

const AI_ACTIONS = [
  {
    id: 'summarize' as AIAction,
    label: 'Summarize',
    icon: Sparkles,
    description: 'Extract key points',
    prompt: (text: string) => `Summarize the following text concisely, extracting the main points:\n\n${text}`,
  },
  {
    id: 'rewrite' as AIAction,
    label: 'Rewrite',
    icon: RefreshCw,
    description: 'Rephrase for clarity',
    prompt: (text: string) => `Rewrite the following text to be clearer and more concise while preserving the original meaning:\n\n${text}`,
  },
  {
    id: 'improve' as AIAction,
    label: 'Improve',
    icon: TrendingUp,
    description: 'Enhance quality',
    prompt: (text: string) => `Improve the following text by enhancing clarity, grammar, and flow:\n\n${text}`,
  },
  {
    id: 'expand' as AIAction,
    label: 'Expand',
    icon: Maximize2,
    description: 'Add more detail',
    prompt: (text: string) => `Expand on the following text by adding more detail, examples, and elaboration:\n\n${text}`,
  },
];

export function AIAssistantDialog({ isOpen, onClose, noteContent, onApply }: AIAssistantDialogProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string>('');
  const [activeAction, setActiveAction] = useState<AIAction | null>(null);
  const { toast } = useToast();

  const plainText = noteContent.replace(/<[^>]*>/g, '').trim();

  const handleAction = async (action: AIAction) => {
    if (!plainText) {
      toast({
        title: "Empty note",
        description: "Write something first to get AI assistance",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setActiveAction(action);
    setResult('');

    try {
      const actionConfig = AI_ACTIONS.find(a => a.id === action);
      if (!actionConfig) return;

      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: actionConfig.prompt(plainText) 
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'AI request failed');
      }

      if (data.result) {
        setResult(data.result);
      }
    } catch (error: any) {
      console.error('AI Error:', error);
      toast({
        title: "AI unavailable",
        description: error.message || "Failed to get AI assistance",
        variant: "destructive",
      });
      setResult('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = async () => {
    if (result) {
      await onApply(result);
      onClose();
      toast({
        title: "AI suggestion applied",
        description: "Your note has been updated",
      });
    }
  };

  const handleReset = () => {
    setResult('');
    setActiveAction(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col" data-testid="dialog-ai-assistant">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Assistant
          </DialogTitle>
          <DialogDescription>
            Choose an action to transform your note with AI
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4">
          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            {AI_ACTIONS.map((action) => {
              const Icon = action.icon;
              const isActive = activeAction === action.id;
              
              return (
                <Button
                  key={action.id}
                  variant={isActive ? "default" : "outline"}
                  className="h-auto flex flex-col items-start p-4 gap-1"
                  onClick={() => handleAction(action.id)}
                  disabled={isLoading || !plainText}
                  data-testid={`button-ai-${action.id}`}
                >
                  <div className="flex items-center gap-2 w-full">
                    <Icon className="w-4 h-4" />
                    <span className="font-semibold">{action.label}</span>
                  </div>
                  <span className="text-xs text-muted-foreground text-left">
                    {action.description}
                  </span>
                </Button>
              );
            })}
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center gap-2 p-8 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Thinking...</span>
            </div>
          )}

          {/* Result Preview */}
          {result && !isLoading && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">AI Suggestion</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleReset}
                  data-testid="button-ai-reset"
                >
                  Try another
                </Button>
              </div>
              <div 
                className="p-4 bg-muted/50 rounded-lg border border-border text-sm whitespace-pre-wrap"
                data-testid="text-ai-result"
              >
                {result}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!result && !isLoading && (
            <div className="text-center p-8 text-muted-foreground text-sm">
              <p>Select an action above to get AI assistance</p>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            data-testid="button-ai-cancel"
          >
            Cancel
          </Button>
          <Button
            onClick={handleApply}
            disabled={!result || isLoading}
            data-testid="button-ai-apply"
          >
            Apply to Note
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
