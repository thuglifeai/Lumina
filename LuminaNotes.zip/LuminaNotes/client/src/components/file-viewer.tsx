import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileViewerProps {
  pdfBlob?: Blob;
  pptxBlob?: Blob;
  onClose: () => void;
}

export function FileViewer({ pdfBlob, pptxBlob, onClose }: FileViewerProps) {
  const [pdfPages, setPdfPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pptxUrl, setPptxUrl] = useState<string>('');
  const [pptxError, setPptxError] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pdfDocRef = useRef<any>(null);

  useEffect(() => {
    // Configure PDF.js worker
    if ((window as any).pdfjsLib) {
      (window as any).pdfjsLib.GlobalWorkerOptions.workerSrc = 
        'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
    }
  }, []);

  useEffect(() => {
    if (pdfBlob) {
      loadPdf();
    }
    return () => {
      if (pdfDocRef.current) {
        pdfDocRef.current.destroy();
      }
    };
  }, [pdfBlob]);

  useEffect(() => {
    if (pptxBlob) {
      loadPptx();
    }
  }, [pptxBlob]);

  useEffect(() => {
    if (pdfDocRef.current && currentPage) {
      renderPage(currentPage);
    }
  }, [currentPage]);

  const loadPdf = async () => {
    if (!pdfBlob || !(window as any).pdfjsLib) return;
    
    try {
      const arrayBuffer = await pdfBlob.arrayBuffer();
      const loadingTask = (window as any).pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      
      pdfDocRef.current = pdf;
      setPdfPages(pdf.numPages);
      setCurrentPage(1);
      renderPage(1);
    } catch (error) {
      console.error('Failed to load PDF:', error);
    }
  };

  const renderPage = async (pageNum: number) => {
    if (!pdfDocRef.current || !canvasRef.current) return;
    
    try {
      const page = await pdfDocRef.current.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.5 });
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) return;
      
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      
      await page.render({
        canvasContext: context,
        viewport: viewport,
      }).promise;
    } catch (error) {
      console.error('Failed to render page:', error);
    }
  };

  const loadPptx = async () => {
    if (!pptxBlob) return;
    
    // Note: Full PowerPoint rendering requires complex libraries
    // For MVP, we show a download option instead of preview
    try {
      const url = URL.createObjectURL(pptxBlob);
      setPptxUrl(url);
      setPptxError(false);
    } catch (error) {
      console.error('Failed to load PowerPoint:', error);
      setPptxError(true);
    }
  };

  if (!pdfBlob && !pptxBlob) return null;

  return (
    <div 
      className={cn(
        "mt-4 sm:mt-6 bg-surface/50 backdrop-blur-glass rounded-lg p-3 sm:p-6",
        "border border-card-border shadow-sm"
      )}
      data-testid="file-viewer"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-foreground">
          {pdfBlob ? 'PDF Document' : 'PowerPoint Presentation'}
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          data-testid="button-close-viewer"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      {pdfBlob && (
        <>
          <div className="flex items-center justify-center gap-4 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              data-testid="button-prev-page"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {currentPage} of {pdfPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.min(pdfPages, p + 1))}
              disabled={currentPage >= pdfPages}
              data-testid="button-next-page"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex justify-center">
            <canvas 
              ref={canvasRef} 
              className="max-w-full shadow-md rounded"
            />
          </div>
        </>
      )}

      {pptxBlob && (
        <div className="text-center py-8">
          {pptxError ? (
            <p className="text-destructive">Failed to load PowerPoint file</p>
          ) : (
            <>
              <p className="text-muted-foreground mb-4">PowerPoint file attached</p>
              <Button
                asChild
                variant="default"
                data-testid="button-download-pptx"
              >
                <a 
                  href={pptxUrl} 
                  download="presentation.pptx"
                >
                  Download Presentation
                </a>
              </Button>
              <p className="text-xs text-muted-foreground mt-4">
                Full PowerPoint preview coming soon
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
