import { useState, useEffect } from "react";
import { type NoteVersion, getVersions, restoreVersion } from "@/lib/db";
import { formatDistanceToNow } from "date-fns";
import { History, RotateCcw, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface VersionHistoryProps {
  noteId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onRestore: (noteId: string) => void;
}

export function VersionHistory({ noteId, isOpen, onClose, onRestore }: VersionHistoryProps) {
  const [versions, setVersions] = useState<NoteVersion[]>([]);
  const [previewVersion, setPreviewVersion] = useState<NoteVersion | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && noteId) {
      loadVersions();
    }
  }, [isOpen, noteId]);

  const loadVersions = async () => {
    if (!noteId) return;
    
    try {
      const noteVersions = await getVersions(noteId);
      setVersions(noteVersions);
    } catch (error) {
      console.error('Failed to load versions:', error);
      toast({
        title: "Error",
        description: "Failed to load version history",
        variant: "destructive",
      });
    }
  };

  const handleRestore = async (versionId: string) => {
    if (!noteId) return;
    
    try {
      await restoreVersion(noteId, versionId);
      
      toast({
        title: "Version restored",
        description: "Your note has been restored to this version",
      });
      
      onRestore(noteId);
      onClose();
    } catch (error) {
      console.error('Failed to restore version:', error);
      toast({
        title: "Error",
        description: "Failed to restore version",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col" data-testid="dialog-version-history">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <History className="w-6 h-6 text-primary" />
              Version History
            </DialogTitle>
            <DialogDescription>
              Every thought leaves a trace. Restore your note to any previous state.
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              {/* Version List */}
              <div className="space-y-2 pr-2">
                {versions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <History className="w-16 h-16 text-muted-foreground/30 mb-4" />
                    <p className="text-muted-foreground">No version history yet</p>
                    <p className="text-muted-foreground text-sm mt-2">
                      Versions are created as you edit
                    </p>
                  </div>
                ) : (
                  versions.map((version, index) => (
                    <div
                      key={version.id}
                      className={cn(
                        "group relative p-3 rounded-md border cursor-pointer",
                        "bg-card border-card-border",
                        "hover-elevate",
                        previewVersion?.id === version.id && "border-primary bg-primary/5"
                      )}
                      onClick={() => setPreviewVersion(version)}
                      data-testid={`version-${version.id}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {index === 0 && (
                              <span className="text-xs font-medium text-primary">Current</span>
                            )}
                            <p className="text-xs text-muted-foreground">
                              {formatDistanceToNow(version.timestamp, { addSuffix: true })}
                            </p>
                          </div>
                          <h4 className="font-medium text-sm truncate">
                            {version.title}
                          </h4>
                        </div>
                        
                        {index !== 0 && (
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 opacity-0 group-hover:opacity-100"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRestore(version.id);
                            }}
                            data-testid={`button-restore-version-${version.id}`}
                            title="Restore this version"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Preview Panel */}
              <div className="border-l pl-4">
                {previewVersion ? (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Eye className="w-4 h-4 text-muted-foreground" />
                      <h3 className="font-medium">Preview</h3>
                    </div>
                    <div
                      className="prose prose-sm dark:prose-invert max-w-none p-4 rounded-md bg-muted/30"
                      dangerouslySetInnerHTML={{ __html: previewVersion.content }}
                      data-testid="version-preview"
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                    Select a version to preview
                  </div>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
