import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Plus, 
  Download, 
  Share2, 
  Bot, 
  Moon, 
  Sun, 
  Monitor,
  History,
  FileText,
  Code,
  FileImage,
  FileType,
  Table,
  Menu
} from "lucide-react";
import { FONT_OPTIONS, FONT_SIZE_OPTIONS } from "@shared/schema";
import { EXPORT_FORMATS, ExportFormat } from "@/lib/export";
import { useTheme } from "./theme-provider";
import { cn } from "@/lib/utils";

interface LuminaHeaderProps {
  onNewNote: () => void;
  onExport: (format: ExportFormat) => void;
  onShare: () => void;
  onAI?: () => void;
  onAttachFile: () => void;
  onVersionHistory?: () => void;
  onToggleSidebar?: () => void;
  isMobile?: boolean;
}

export function LuminaHeader({ 
  onNewNote, 
  onExport, 
  onShare, 
  onAI,
  onAttachFile,
  onVersionHistory,
  onToggleSidebar,
  isMobile = false
}: LuminaHeaderProps) {
  const { settings, updateSettings } = useTheme();

  const themeIcons = {
    light: <Sun className="w-4 h-4" />,
    dark: <Moon className="w-4 h-4" />,
    system: <Monitor className="w-4 h-4" />,
  };

  return (
    <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border px-3 sm:px-6 py-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {/* Mobile Menu Button */}
          {isMobile && onToggleSidebar && (
            <Button
              size="icon"
              variant="ghost"
              onClick={onToggleSidebar}
              className="min-h-11 min-w-11"
              data-testid="button-toggle-sidebar"
            >
              <Menu className="w-5 h-5" />
            </Button>
          )}
          
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight lumina-brand-glow">
            Lumina
          </h1>
        </div>

        <div className="flex items-center gap-1 sm:gap-2 md:gap-3">
          {/* Font Selector - Hidden on mobile */}
          <div className="hidden lg:block">
            <Select
              value={settings.fontFamily}
              onValueChange={(value: any) => updateSettings({ fontFamily: value })}
            >
              <SelectTrigger 
                className="w-48 h-9 text-xs"
                data-testid="select-font"
              >
                <SelectValue placeholder="Select font" />
              </SelectTrigger>
            <SelectContent>
              {/* System Fonts */}
              <SelectGroup>
                <SelectLabel>System Fonts</SelectLabel>
                {FONT_OPTIONS.filter(f => 'system' in f && f.system).map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
              
              {/* Sans-serif Fonts */}
              <SelectGroup>
                <SelectLabel>Sans-serif</SelectLabel>
                {FONT_OPTIONS.filter(f => f.category === 'sans-serif').map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
              
              {/* Serif Fonts */}
              <SelectGroup>
                <SelectLabel>Serif</SelectLabel>
                {FONT_OPTIONS.filter(f => f.category === 'serif').map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
              
              {/* Monospace Fonts */}
              <SelectGroup>
                <SelectLabel>Monospace</SelectLabel>
                {FONT_OPTIONS.filter(f => f.category === 'monospace').map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
              
              {/* Script Fonts */}
              <SelectGroup>
                <SelectLabel>Script / Handwriting</SelectLabel>
                {FONT_OPTIONS.filter(f => f.category === 'script').map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
              
              {/* Display Fonts */}
              <SelectGroup>
                <SelectLabel>Display / Impact</SelectLabel>
                {FONT_OPTIONS.filter(f => f.category === 'display').map((font) => (
                  <SelectItem 
                    key={font.key} 
                    value={font.key}
                    data-testid={`font-option-${font.key}`}
                  >
                    {font.name}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
            </Select>
          </div>

          {/* Font Size Selector - Hidden on mobile */}
          <div className="hidden md:block">
            <Select
              value={settings.fontSize?.toString() || '16'}
              onValueChange={(value) => updateSettings({ fontSize: parseInt(value) })}
            >
              <SelectTrigger 
                className="w-32 h-9 text-xs"
                data-testid="select-font-size"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FONT_SIZE_OPTIONS.map((size) => (
                  <SelectItem 
                    key={size.value} 
                    value={size.value.toString()}
                    data-testid={`font-size-option-${size.value}`}
                  >
                    {size.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Accent Color Picker */}
          <div className="relative">
            <input
              type="color"
              value={settings.accentColor}
              onChange={(e) => updateSettings({ accentColor: e.target.value })}
              className="w-9 h-9 rounded-md border-2 border-border cursor-pointer"
              title="Accent color"
              data-testid="input-accent-color"
            />
          </div>

          {/* Theme Selector */}
          <Select
            value={settings.theme}
            onValueChange={(value: any) => updateSettings({ theme: value })}
          >
            <SelectTrigger 
              className="w-28 h-9 text-xs"
              data-testid="select-theme"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light" data-testid="theme-option-light">
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4" />
                  Light
                </div>
              </SelectItem>
              <SelectItem value="dark" data-testid="theme-option-dark">
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4" />
                  Dark
                </div>
              </SelectItem>
              <SelectItem value="system" data-testid="theme-option-system">
                <div className="flex items-center gap-2">
                  <Monitor className="w-4 h-4" />
                  System
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          {/* Action Buttons */}
          <Button
            variant="outline"
            size="sm"
            onClick={onAttachFile}
            title="Attach PDF or PowerPoint"
            data-testid="button-attach-file"
            className="hidden sm:flex min-h-11 min-w-11"
          >
            📄
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                title="Export note"
                data-testid="button-export"
                className="hidden sm:flex min-h-11 min-w-11"
              >
                <Download className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              {EXPORT_FORMATS.map((format) => {
                const Icon = format.icon === 'FileText' ? FileText :
                            format.icon === 'Code' ? Code :
                            format.icon === 'FileImage' ? FileImage :
                            format.icon === 'FileType' ? FileType :
                            Table;
                
                return (
                  <DropdownMenuItem
                    key={format.value}
                    onClick={() => onExport(format.value)}
                    data-testid={`export-${format.value}`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {format.label}
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="outline"
            size="sm"
            onClick={onShare}
            title="Share note"
            data-testid="button-share"
            className="hidden md:flex min-h-11 min-w-11"
          >
            <Share2 className="w-4 h-4" />
          </Button>

          {onVersionHistory && (
            <Button
              variant="outline"
              size="sm"
              onClick={onVersionHistory}
              title="Version History"
              data-testid="button-version-history"
              className="hidden md:flex min-h-11 min-w-11"
            >
              <History className="w-4 h-4" />
            </Button>
          )}

          {onAI && (
            <Button
              variant="outline"
              size="sm"
              onClick={onAI}
              title="AI Assistant"
              data-testid="button-ai"
              className="min-h-11 min-w-11"
            >
              <Bot className="w-4 h-4" />
            </Button>
          )}

          <Button
            variant="default"
            size="sm"
            onClick={onNewNote}
            title="New note"
            data-testid="button-new-note"
            className="min-h-11 min-w-11"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
