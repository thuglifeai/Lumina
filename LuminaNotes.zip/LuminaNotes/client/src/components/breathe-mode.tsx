import { useEffect, useState } from "react";

export function BreatheMode() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isVisible) {
        setIsVisible(true);
        
        // Auto-dismiss after 8 seconds
        setTimeout(() => {
          setIsVisible(false);
        }, 8000);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex flex-col items-center justify-center text-white animate-fade-in"
      onClick={() => setIsVisible(false)}
    >
      <div className="w-32 h-32 rounded-full border-4 border-white/40 mb-8 animate-breathe" />
      
      <p className="text-2xl font-light mb-2">Breathe in... and out</p>
      
      <p className="text-sm text-white/60">Press ESC to return</p>
    </div>
  );
}
