import { useState, useEffect } from "react";
import { Note } from "@shared/schema";
import { getAllDeletedNotes, restoreNote, permanentlyDeleteNote } from "@/lib/db";
import { formatDistanceToNow } from "date-fns";
import { Sparkles, RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface NightSkyArchiveProps {
  isOpen: boolean;
  onClose: () => void;
  onRestore: () => void;
}

export function NightSkyArchive({ isOpen, onClose, onRestore }: NightSkyArchiveProps) {
  const [deletedNotes, setDeletedNotes] = useState<Note[]>([]);
  const [permanentDeleteId, setPermanentDeleteId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      loadDeletedNotes();
    }
  }, [isOpen]);

  const loadDeletedNotes = async () => {
    try {
      const notes = await getAllDeletedNotes();
      setDeletedNotes(notes);
    } catch (error) {
      console.error('Failed to load deleted notes:', error);
      toast({
        title: "Error",
        description: "Failed to load archive",
        variant: "destructive",
      });
    }
  };

  const handleRestore = async (id: string) => {
    try {
      await restoreNote(id);
      setDeletedNotes(deletedNotes.filter(n => n.id !== id));
      
      toast({
        title: "Note restored",
        description: "The thought has returned from the night sky",
      });
      
      onRestore();
    } catch (error) {
      console.error('Failed to restore note:', error);
      toast({
        title: "Error",
        description: "Failed to restore note",
        variant: "destructive",
      });
    }
  };

  const handlePermanentDelete = async (id: string) => {
    try {
      await permanentlyDeleteNote(id);
      setDeletedNotes(deletedNotes.filter(n => n.id !== id));
      
      toast({
        title: "Note permanently deleted",
        description: "The thought has faded into the void",
      });
      
      setPermanentDeleteId(null);
    } catch (error) {
      console.error('Failed to permanently delete note:', error);
      toast({
        title: "Error",
        description: "Failed to delete note",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col" data-testid="dialog-night-sky-archive">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <Sparkles className="w-6 h-6 text-primary" />
              Night Sky Archive
            </DialogTitle>
            <DialogDescription>
              Your deleted thoughts drift here among the stars, waiting to be restored.
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-3 pr-2">
            {deletedNotes.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Sparkles className="w-16 h-16 text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground text-lg">The night sky is clear</p>
                <p className="text-muted-foreground text-sm mt-2">
                  No archived thoughts yet
                </p>
              </div>
            ) : (
              deletedNotes.map((note) => (
                <div
                  key={note.id}
                  className={cn(
                    "group relative p-4 rounded-md",
                    "bg-card border border-card-border",
                    "hover-elevate"
                  )}
                  data-testid={`archived-note-${note.id}`}
                >
                  <div className="pr-20">
                    <h3 className="font-medium text-card-foreground mb-1">
                      {note.title}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      Deleted {formatDistanceToNow(note.deletedAt || Date.now(), { addSuffix: true })}
                    </p>
                  </div>

                  <div className="absolute top-3 right-3 flex gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={() => handleRestore(note.id)}
                      data-testid={`button-restore-${note.id}`}
                      title="Restore note"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => setPermanentDeleteId(note.id)}
                      data-testid={`button-permanent-delete-${note.id}`}
                      title="Permanently delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!permanentDeleteId} onOpenChange={() => setPermanentDeleteId(null)}>
        <AlertDialogContent data-testid="dialog-permanent-delete-confirm">
          <AlertDialogHeader>
            <AlertDialogTitle>Fade this thought into the void?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The note will be permanently deleted and cannot be restored.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-permanent-delete">
              Keep in archive
            </AlertDialogCancel>
            <AlertDialogAction
              data-testid="button-confirm-permanent-delete"
              onClick={() => permanentDeleteId && handlePermanentDelete(permanentDeleteId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Permanently delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
