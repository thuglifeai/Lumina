import { Note } from "@shared/schema";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { Trash2, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface NoteSidebarProps {
  notes: Note[];
  currentNoteId: string | null;
  onSelectNote: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onRenameNote: (id: string, newTitle: string) => void;
}

export function NoteSidebar({ notes, currentNoteId, onSelectNote, onDeleteNote, onRenameNote }: NoteSidebarProps) {
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [renamingNoteId, setRenamingNoteId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState("");

  const handleRenameClick = (note: Note) => {
    setRenamingNoteId(note.id);
    setNewTitle(note.title);
    setRenameDialogOpen(true);
  };

  const handleRenameSubmit = () => {
    if (renamingNoteId && newTitle.trim()) {
      onRenameNote(renamingNoteId, newTitle.trim());
      setRenameDialogOpen(false);
      setRenamingNoteId(null);
      setNewTitle("");
    }
  };

  return (
    <>
      <div className="w-full lg:w-72 bg-sidebar border-r border-sidebar-border h-full overflow-y-auto p-4">
        <div className="space-y-2">
          {notes.map((note) => (
            <div
              key={note.id}
              className={cn(
                "group relative p-4 rounded-md transition-all duration-200",
                "bg-card border border-card-border",
                "hover-elevate",
                currentNoteId === note.id && "border-l-4 border-l-primary shadow-md"
              )}
              data-testid={`note-card-${note.id}`}
            >
              <button
                onClick={() => onSelectNote(note.id)}
                className="w-full text-left focus:outline-none"
                data-testid={`button-select-note-${note.id}`}
              >
                <h3 className="font-medium text-card-foreground text-sm truncate mb-1 pr-16">
                  {note.title}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(note.updatedAt, { addSuffix: true })}
                </p>
              </button>

              <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7"
                  data-testid={`button-rename-note-${note.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRenameClick(note);
                  }}
                >
                  <Pencil className="h-3.5 w-3.5" />
                </Button>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7"
                      data-testid={`button-delete-note-${note.id}`}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent data-testid="dialog-delete-confirm">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Release this thought to the night sky?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This note will drift into the Night Sky Archive, where you can restore it later if needed.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel data-testid="button-cancel-delete">Keep writing</AlertDialogCancel>
                      <AlertDialogAction
                        data-testid="button-confirm-delete"
                        onClick={() => onDeleteNote(note.id)}
                      >
                        Release to archive
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
        <DialogContent data-testid="dialog-rename-note">
          <DialogHeader>
            <DialogTitle>Rename Note</DialogTitle>
            <DialogDescription>
              Give your thought a new name
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="note-title">Title</Label>
              <Input
                id="note-title"
                data-testid="input-note-title"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleRenameSubmit();
                  }
                }}
                placeholder="Enter note title..."
                autoFocus
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setRenameDialogOpen(false)}
              data-testid="button-cancel-rename"
            >
              Cancel
            </Button>
            <Button
              onClick={handleRenameSubmit}
              data-testid="button-confirm-rename"
              disabled={!newTitle.trim()}
            >
              Rename
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
