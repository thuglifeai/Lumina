import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { TaskList, TaskItem } from '@tiptap/extension-list';
import { useEffect } from 'react';
import { cn } from '@/lib/utils';

interface NoteEditorProps {
  content: string;
  onChange: (content: string) => void;
}

export function NoteEditor({ content, onChange }: NoteEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
        },
      }),
      TaskList,
      TaskItem.configure({
        nested: true,
      }),
    ],
    content,
    editorProps: {
      attributes: {
        class: cn(
          'prose max-w-none',
          'focus:outline-none',
          'min-h-[400px]',
          'text-foreground'
        ),
      },
    },
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
  });

  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content);
    }
  }, [content, editor]);

  return (
    <div 
      className={cn(
        "bg-surface/50 backdrop-blur-glass rounded-lg p-3 sm:p-6",
        "border border-card-border",
        "shadow-sm",
        "transition-all duration-200",
        "focus-within:shadow-md focus-within:ring-2 focus-within:ring-primary/10"
      )}
      data-testid="note-editor"
    >
      <EditorContent editor={editor} />
    </div>
  );
}
