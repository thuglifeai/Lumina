import { createContext, useContext, useEffect, useState } from "react";
import { UserSettings, defaultSettings } from "@shared/schema";
import { getSettings, saveSettings, applyTheme, applyFont, applyFontSize, applyAccentColor } from "@/lib/settings";

type ThemeProviderContextType = {
  settings: UserSettings;
  updateSettings: (updates: Partial<UserSettings>) => void;
};

const ThemeProviderContext = createContext<ThemeProviderContextType>({
  settings: defaultSettings,
  updateSettings: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<UserSettings>(getSettings);

  useEffect(() => {
    // Apply initial settings
    applyTheme(settings.theme);
    applyFont(settings.fontFamily);
    applyFontSize(settings.fontSize);
    applyAccentColor(settings.accentColor);

    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      if (settings.theme === 'system') {
        applyTheme('system');
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings]);

  const updateSettings = (updates: Partial<UserSettings>) => {
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    saveSettings(newSettings); // Save the full merged settings, not just the updates
    
    // Apply changes immediately
    if (updates.theme) applyTheme(updates.theme);
    if (updates.fontFamily) applyFont(updates.fontFamily);
    if (updates.fontSize !== undefined) applyFontSize(updates.fontSize);
    if (updates.accentColor) applyAccentColor(updates.accentColor);
  };

  return (
    <ThemeProviderContext.Provider value={{ settings, updateSettings }}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeProviderContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}
