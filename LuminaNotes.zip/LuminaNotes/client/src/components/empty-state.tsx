import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyStateProps {
  onCreateFirst: () => void;
}

export function EmptyState({ onCreateFirst }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center h-screen px-4 animate-fade-in">
      <div className="text-6xl mb-8 animate-spark-pulse">
        <Sparkles className="w-16 h-16 text-primary" strokeWidth={1.5} />
      </div>
      
      <h2 className="text-2xl font-semibold text-foreground mb-3 tracking-tight">
        Light begins with a single thought
      </h2>
      
      <p className="text-muted-foreground mb-10 text-center max-w-md leading-relaxed">
        Your thoughts, beautifully kept in a sanctuary of privacy and calm.
      </p>
      
      <Button
        onClick={onCreateFirst}
        size="lg"
        className="rounded-lg px-8 py-6 text-base font-medium shadow-lg hover:shadow-xl transition-all duration-200"
        data-testid="button-create-first-note"
      >
        Begin
      </Button>
    </div>
  );
}
