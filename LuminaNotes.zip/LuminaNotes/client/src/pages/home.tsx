import { useState, useEffect, useRef } from "react";
import { Note } from "@shared/schema";
import { saveNote, getAllNotes, extractTitle, deleteNote, saveVersion, getNote } from "@/lib/db";
import { EmptyState } from "@/components/empty-state";
import { NoteSidebar } from "@/components/note-sidebar";
import { NoteEditor } from "@/components/note-editor";
import { FileViewer } from "@/components/file-viewer";
import { LuminaHeader } from "@/components/lumina-header";
import { BreatheMode } from "@/components/breathe-mode";
import { NightSkyArchive } from "@/components/night-sky-archive";
import { VersionHistory } from "@/components/version-history";
import { AIAssistantDialog } from "@/components/ai-assistant-dialog";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import DOMPurify from 'isomorphic-dompurify';
import { marked } from 'marked';
import { exportNote, ExportFormat } from "@/lib/export";

export default function Home() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [currentNote, setCurrentNote] = useState<Note | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showArchive, setShowArchive] = useState(false);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const lastVersionSave = useRef<{ noteId: string; timestamp: number } | null>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();

  useEffect(() => {
    loadNotes();
    
    // Check for shared note in URL query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const sharedData = urlParams.get('shared');
    
    if (sharedData) {
      try {
        // Decode the shared note
        const decoded = JSON.parse(decodeURIComponent(atob(sharedData)));
        
        // Create a new note from the shared content
        const newNote: Note = {
          id: crypto.randomUUID(),
          title: decoded.title || 'Shared Note',
          content: decoded.content || '',
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };

        // Save to IndexedDB and set as current
        setTimeout(async () => {
          await saveNote(newNote);
          const allNotes = await getAllNotes();
          setNotes(allNotes);
          setCurrentNote(newNote);
          
          toast({
            title: "Shared note loaded",
            description: `${newNote.title} has been added to your notes`,
          });

          // Clean up URL
          window.history.replaceState({}, '', window.location.pathname);
        }, 500);
      } catch (error) {
        console.error('Failed to load shared note:', error);
        toast({
          title: "Invalid share link",
          description: "Could not load the shared note",
          variant: "destructive",
        });
        
        // Clean up URL even on error
        window.history.replaceState({}, '', window.location.pathname);
      }
    }

    // Keyboard shortcut: Ctrl+Shift+A to open Night Sky Archive
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        setShowArchive(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const loadNotes = async () => {
    try {
      const allNotes = await getAllNotes();
      setNotes(allNotes);
      
      if (allNotes.length > 0 && !currentNote) {
        setCurrentNote(allNotes[0]);
      }
    } catch (error) {
      console.error('Failed to load notes:', error);
      toast({
        title: "Error",
        description: "Failed to load notes",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createNewNote = async () => {
    const newNote: Note = {
      id: `note-${Date.now()}`,
      content: '',
      title: 'Start writing...',
      updatedAt: Date.now(),
    };

    try {
      await saveNote(newNote);
      setNotes([newNote, ...notes]);
      setCurrentNote(newNote);
    } catch (error) {
      console.error('Failed to create note:', error);
      toast({
        title: "Error",
        description: "Failed to create note",
        variant: "destructive",
      });
    }
  };

  const handleContentChange = async (content: string) => {
    if (!currentNote) return;

    const updatedNote: Note = {
      ...currentNote,
      content,
      title: extractTitle(content),
      updatedAt: Date.now(),
    };

    try {
      await saveNote(updatedNote);
      setCurrentNote(updatedNote);
      setNotes(notes.map(n => n.id === updatedNote.id ? updatedNote : n));
      
      // Save version every 5 minutes or on first edit
      const now = Date.now();
      const lastSave = lastVersionSave.current;
      const shouldSaveVersion = !lastSave || 
        lastSave.noteId !== currentNote.id || 
        now - lastSave.timestamp > 5 * 60 * 1000; // 5 minutes
      
      if (shouldSaveVersion && content.trim()) {
        await saveVersion(currentNote.id, content, extractTitle(content));
        lastVersionSave.current = { noteId: currentNote.id, timestamp: now };
      }
    } catch (error) {
      console.error('Failed to save note:', error);
    }
  };

  const handleSelectNote = (id: string) => {
    const note = notes.find(n => n.id === id);
    if (note) {
      setCurrentNote(note);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      await deleteNote(id);
      const remainingNotes = notes.filter(n => n.id !== id);
      setNotes(remainingNotes);
      
      if (currentNote?.id === id) {
        setCurrentNote(remainingNotes[0] || null);
      }
      
      toast({
        title: "Note released",
        description: "The note has been moved to the Night Sky Archive",
      });
    } catch (error) {
      console.error('Failed to delete note:', error);
      toast({
        title: "Error",
        description: "Failed to delete note",
        variant: "destructive",
      });
    }
  };

  const handleRenameNote = async (id: string, newTitle: string) => {
    try {
      const noteToRename = await getNote(id);
      if (!noteToRename) return;

      const updatedNote = { ...noteToRename, title: newTitle, updatedAt: Date.now() };
      await saveNote(updatedNote);
      
      setNotes(prevNotes =>
        prevNotes.map(n => n.id === id ? updatedNote : n)
      );
      
      if (currentNote?.id === id) {
        setCurrentNote(prev => prev ? { ...prev, title: newTitle } : null);
      }
      
      toast({
        title: "Note renamed",
        description: `Renamed to "${newTitle}"`,
      });
    } catch (error) {
      console.error('Failed to rename note:', error);
      toast({
        title: "Error",
        description: "Failed to rename note",
        variant: "destructive",
      });
    }
  };

  const handleExport = async (format: ExportFormat) => {
    if (!currentNote) return;

    try {
      await exportNote(format, currentNote.content, currentNote.title);
      
      toast({
        title: "Exported",
        description: `Note exported as ${format.toUpperCase()}`,
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "Export failed",
        description: "Could not export note",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (!currentNote) return;

    try {
      // Create a shareable payload (without file attachments for URL size limits)
      const sharePayload = {
        title: currentNote.title,
        content: currentNote.content,
        timestamp: currentNote.updatedAt,
      };

      // Encode as base64 for URL
      const encoded = btoa(encodeURIComponent(JSON.stringify(sharePayload)));
      const shareUrl = `${window.location.origin}?shared=${encoded}`;

      // Check URL length (browser limits ~2000 chars)
      if (shareUrl.length > 2000) {
        toast({
          title: "Note too large",
          description: "This note is too large to share via link. Try exporting to HTML instead.",
          variant: "destructive",
        });
        return;
      }

      await navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Link copied",
        description: "Share this link to open the note anywhere",
      });
    } catch (error) {
      console.error('Share error:', error);
      toast({
        title: "Share failed",
        description: "Could not create share link",
        variant: "destructive",
      });
    }
  };

  const handleAttachFile = () => {
    if (!currentNote) return;

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf,.pptx';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const ext = file.name.split('.').pop()?.toLowerCase();
      
      const updatedNote: Note = {
        ...currentNote,
        updatedAt: Date.now(),
      };

      if (ext === 'pdf') {
        updatedNote.pdf = file;
        updatedNote.pptx = undefined;
      } else if (ext === 'pptx') {
        updatedNote.pptx = file;
        updatedNote.pdf = undefined;
      } else {
        toast({
          title: "Invalid file",
          description: "Only PDF and PowerPoint files are supported",
          variant: "destructive",
        });
        return;
      }

      try {
        await saveNote(updatedNote);
        setCurrentNote(updatedNote);
        setNotes(notes.map(n => n.id === updatedNote.id ? updatedNote : n));
        
        toast({
          title: "File attached",
          description: `${ext.toUpperCase()} file attached successfully`,
        });
      } catch (error) {
        console.error('Failed to attach file:', error);
        toast({
          title: "Error",
          description: "Failed to attach file",
          variant: "destructive",
        });
      }
    };

    input.click();
  };

  const handleCloseViewer = async () => {
    if (!currentNote) return;

    const updatedNote: Note = {
      ...currentNote,
      pdf: undefined,
      pptx: undefined,
      updatedAt: Date.now(),
    };

    try {
      await saveNote(updatedNote);
      setCurrentNote(updatedNote);
      setNotes(notes.map(n => n.id === updatedNote.id ? updatedNote : n));
    } catch (error) {
      console.error('Failed to remove file:', error);
    }
  };

  const handleAIApply = async (result: string) => {
    if (!currentNote) return;
    
    // Check if result already contains HTML tags
    const hasHtmlTags = /<[a-z][\s\S]*>/i.test(result);
    
    let htmlContent: string;
    
    if (hasHtmlTags) {
      // AI returned HTML - use as-is
      htmlContent = result;
    } else {
      // AI returned plain text or Markdown - convert to HTML using marked
      try {
        htmlContent = await marked.parse(result);
      } catch (error) {
        console.error('Markdown parsing error:', error);
        // Fallback to simple paragraph conversion
        htmlContent = result
          .split('\n\n')
          .filter(p => p.trim())
          .map(p => {
            const withBreaks = p.trim().replace(/\n/g, '<br />');
            return `<p>${withBreaks}</p>`;
          })
          .join('');
      }
    }
    
    // Sanitize with DOMPurify to allow safe tags only
    const formattedContent = DOMPurify.sanitize(htmlContent, {
      ALLOWED_TAGS: ['p', 'br', 'strong', 'em', 'u', 's', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'blockquote', 'code', 'pre', 'a', 'hr'],
      ALLOWED_ATTR: ['href', 'target', 'rel'],
      ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
    });
    
    // Append AI result to existing content with a separator
    const separator = '<hr /><p><strong>AI Suggestion:</strong></p>';
    const updatedContent = currentNote.content + separator + formattedContent;
    
    handleContentChange(updatedContent);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-glow-pulse text-primary">Loading...</div>
      </div>
    );
  }

  if (notes.length === 0) {
    return (
      <>
        <EmptyState onCreateFirst={createNewNote} />
        <BreatheMode />
        <NightSkyArchive
          isOpen={showArchive}
          onClose={() => setShowArchive(false)}
          onRestore={loadNotes}
        />
      </>
    );
  }

  return (
    <div className="h-screen flex flex-col">
      <LuminaHeader
        onNewNote={createNewNote}
        onExport={handleExport}
        onShare={handleShare}
        onAttachFile={handleAttachFile}
        onVersionHistory={() => setShowVersionHistory(true)}
        onAI={() => setShowAIDialog(true)}
        onToggleSidebar={() => setMobileSidebarOpen(true)}
        isMobile={isMobile}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop Sidebar - always visible on desktop */}
        {!isMobile && (
          <NoteSidebar
            notes={notes}
            currentNoteId={currentNote?.id || null}
            onSelectNote={handleSelectNote}
            onDeleteNote={handleDeleteNote}
            onRenameNote={handleRenameNote}
          />
        )}

        {/* Mobile Sidebar - slide-in drawer */}
        {isMobile && (
          <Sheet open={mobileSidebarOpen} onOpenChange={setMobileSidebarOpen}>
            <SheetContent side="left" className="p-0 w-80">
              <NoteSidebar
                notes={notes}
                currentNoteId={currentNote?.id || null}
                onSelectNote={(id) => {
                  handleSelectNote(id);
                  setMobileSidebarOpen(false);
                }}
                onDeleteNote={handleDeleteNote}
                onRenameNote={handleRenameNote}
              />
            </SheetContent>
          </Sheet>
        )}

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-12">
          <div className="max-w-3xl mx-auto">
            {currentNote && (
              <>
                <NoteEditor
                  content={currentNote.content}
                  onChange={handleContentChange}
                />

                {(currentNote.pdf || currentNote.pptx) && (
                  <FileViewer
                    pdfBlob={currentNote.pdf}
                    pptxBlob={currentNote.pptx}
                    onClose={handleCloseViewer}
                  />
                )}
              </>
            )}
          </div>
        </main>
      </div>

      <BreatheMode />
      <NightSkyArchive
        isOpen={showArchive}
        onClose={() => setShowArchive(false)}
        onRestore={loadNotes}
      />
      <VersionHistory
        noteId={currentNote?.id || null}
        isOpen={showVersionHistory}
        onClose={() => setShowVersionHistory(false)}
        onRestore={async (noteId) => {
          try {
            const updatedNote = await getNote(noteId);
            if (!updatedNote) {
              toast({
                title: "Error",
                description: "Could not load restored note",
                variant: "destructive",
              });
              return;
            }
            
            setCurrentNote(updatedNote);
            setNotes(prevNotes => prevNotes.map(n => n.id === noteId ? updatedNote : n));
          } catch (error) {
            console.error('Failed to refresh after restore:', error);
            toast({
              title: "Error",
              description: "Failed to refresh note",
              variant: "destructive",
            });
          }
        }}
      />
      <AIAssistantDialog
        isOpen={showAIDialog}
        onClose={() => setShowAIDialog(false)}
        noteContent={currentNote?.content || ''}
        onApply={handleAIApply}
      />
    </div>
  );
}
