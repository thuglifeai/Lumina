// IndexedDB utilities for Lumina notes
import { Note } from "@shared/schema";

const DB_NAME = 'lumina-notes';
const STORE_NAME = 'notes';
const DELETED_STORE_NAME = 'deleted-notes';
const VERSIONS_STORE_NAME = 'note-versions';
const DB_VERSION = 3;

interface NoteVersion {
  id: string;
  noteId: string;
  content: string;
  title: string;
  timestamp: number;
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(DELETED_STORE_NAME)) {
        db.createObjectStore(DELETED_STORE_NAME, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(VERSIONS_STORE_NAME)) {
        const versionStore = db.createObjectStore(VERSIONS_STORE_NAME, { keyPath: 'id' });
        versionStore.createIndex('noteId', 'noteId', { unique: false });
      }
    };
  });
}

export async function saveNote(note: Note): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(note);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getAllNotes(): Promise<Note[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();
    
    request.onsuccess = () => {
      const notes = request.result as Note[];
      // Sort by most recently updated
      notes.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(notes);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getNote(id: string): Promise<Note | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(id);
    
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

export async function deleteNote(id: string): Promise<void> {
  const db = await openDatabase();
  
  return new Promise(async (resolve, reject) => {
    try {
      // First, get the note to move it to deleted store
      const note = await getNote(id);
      if (!note) {
        reject(new Error('Note not found'));
        return;
      }

      // Add deletedAt timestamp
      const deletedNote = {
        ...note,
        deletedAt: Date.now(),
      };

      const transaction = db.transaction([STORE_NAME, DELETED_STORE_NAME], 'readwrite');
      const notesStore = transaction.objectStore(STORE_NAME);
      const deletedStore = transaction.objectStore(DELETED_STORE_NAME);
      
      // Use put to handle repeated deletes (overwrites existing archived entries)
      deletedStore.put(deletedNote);
      notesStore.delete(id);
      
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    } catch (error) {
      reject(error);
    }
  });
}

export async function getAllDeletedNotes(): Promise<Note[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DELETED_STORE_NAME, 'readonly');
    const store = transaction.objectStore(DELETED_STORE_NAME);
    const request = store.getAll();
    
    request.onsuccess = () => {
      const notes = request.result as Note[];
      // Sort by deletion time (most recent first)
      notes.sort((a, b) => (b.deletedAt || 0) - (a.deletedAt || 0));
      resolve(notes);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function restoreNote(id: string): Promise<void> {
  const db = await openDatabase();
  
  return new Promise(async (resolve, reject) => {
    try {
      // Get the deleted note
      const transaction1 = db.transaction(DELETED_STORE_NAME, 'readonly');
      const deletedStore = transaction1.objectStore(DELETED_STORE_NAME);
      const getRequest = deletedStore.get(id);
      
      getRequest.onsuccess = () => {
        const note = getRequest.result;
        if (!note) {
          reject(new Error('Deleted note not found'));
          return;
        }

        // Remove deletedAt and restore
        const restoredNote: Note = {
          id: note.id,
          content: note.content,
          title: note.title,
          updatedAt: Date.now(),
          pdf: note.pdf,
          pptx: note.pptx,
        };

        const transaction2 = db.transaction([STORE_NAME, DELETED_STORE_NAME], 'readwrite');
        const notesStore = transaction2.objectStore(STORE_NAME);
        const deletedStore2 = transaction2.objectStore(DELETED_STORE_NAME);
        
        // Use put to handle repeated restore/delete cycles
        notesStore.put(restoredNote);
        deletedStore2.delete(id);
        
        transaction2.oncomplete = () => resolve();
        transaction2.onerror = () => reject(transaction2.error);
      };
      
      getRequest.onerror = () => reject(getRequest.error);
    } catch (error) {
      reject(error);
    }
  });
}

export async function permanentlyDeleteNote(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DELETED_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(DELETED_STORE_NAME);
    const request = store.delete(id);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// Version History Functions
export async function saveVersion(noteId: string, content: string, title: string): Promise<void> {
  const db = await openDatabase();
  
  const version: NoteVersion = {
    id: `version-${noteId}-${Date.now()}`,
    noteId,
    content,
    title,
    timestamp: Date.now(),
  };
  
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(VERSIONS_STORE_NAME, 'readwrite');
    const store = transaction.objectStore(VERSIONS_STORE_NAME);
    const request = store.add(version);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getVersions(noteId: string): Promise<NoteVersion[]> {
  const db = await openDatabase();
  
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(VERSIONS_STORE_NAME, 'readonly');
    const store = transaction.objectStore(VERSIONS_STORE_NAME);
    const index = store.index('noteId');
    const request = index.getAll(noteId);
    
    request.onsuccess = () => {
      const versions = request.result as NoteVersion[];
      versions.sort((a, b) => b.timestamp - a.timestamp);
      resolve(versions);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function restoreVersion(noteId: string, versionId: string): Promise<Note | null> {
  const db = await openDatabase();
  
  return new Promise((resolve, reject) => {
    const transaction1 = db.transaction(VERSIONS_STORE_NAME, 'readonly');
    const versionStore = transaction1.objectStore(VERSIONS_STORE_NAME);
    const getVersionRequest = versionStore.get(versionId);
    
    getVersionRequest.onsuccess = async () => {
      const version = getVersionRequest.result as NoteVersion;
      if (!version) {
        reject(new Error('Version not found'));
        return;
      }
      
      const note = await getNote(noteId);
      if (!note) {
        reject(new Error('Note not found'));
        return;
      }
      
      const restoredNote: Note = {
        ...note,
        content: version.content,
        title: version.title,
        updatedAt: Date.now(),
      };
      
      await saveNote(restoredNote);
      resolve(restoredNote);
    };
    
    getVersionRequest.onerror = () => reject(getVersionRequest.error);
  });
}

export type { NoteVersion };

// Extract plain text title from HTML content
export function extractTitle(htmlContent: string): string {
  const text = htmlContent.replace(/<[^>]*>/g, '').trim();
  const title = text.substring(0, 50);
  return title || 'Untitled';
}
