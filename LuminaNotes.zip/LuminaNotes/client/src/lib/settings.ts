// LocalStorage utilities for user settings
import { UserSettings, defaultSettings, FONT_OPTIONS } from "@shared/schema";

const SETTINGS_KEY = 'lumina-settings';

export function getSettings(): UserSettings {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      
      // Migrate old font family values to new key system
      if (parsed.fontFamily) {
        const fontFamily = parsed.fontFamily;
        
        // Check if it's already a valid key
        const isValidKey = FONT_OPTIONS.some(f => f.key === fontFamily);
        
        if (!isValidKey) {
          // Try to find by family (CSS stack) - for old stored values
          const fontOption = FONT_OPTIONS.find(f => f.family === fontFamily);
          if (fontOption) {
            parsed.fontFamily = fontOption.key;
          } else {
            // Fallback to default
            parsed.fontFamily = defaultSettings.fontFamily;
          }
        }
      }
      
      return { ...defaultSettings, ...parsed };
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
  return defaultSettings;
}

export function saveSettings(settings: Partial<UserSettings>): void {
  try {
    const current = getSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Failed to save settings:', error);
  }
}

export function applyTheme(theme: UserSettings['theme']): void {
  const root = document.documentElement;
  
  if (theme === 'system') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.classList.toggle('dark', prefersDark);
  } else {
    root.classList.toggle('dark', theme === 'dark');
  }
}

export function applyFont(fontKey: string): void {
  const root = document.documentElement;
  
  // Find the font option by key
  const fontOption = FONT_OPTIONS.find(f => f.key === fontKey);
  if (!fontOption) return;
  
  // Apply the font family CSS
  root.style.setProperty('--font-sans', fontOption.family);
  
  // Load Google Font if needed
  loadGoogleFont(fontKey);
}

function loadGoogleFont(fontKey: string): void {
  // Check if this font needs to be loaded from Google Fonts
  const fontOption = FONT_OPTIONS.find(f => f.key === fontKey);
  
  if (!fontOption || !('google' in fontOption) || !fontOption.google) return; // System font or already loaded
  
  // Check if we already have a link element for dynamic fonts
  let linkElement = document.getElementById('dynamic-google-font') as HTMLLinkElement;
  
  if (!linkElement) {
    linkElement = document.createElement('link');
    linkElement.id = 'dynamic-google-font';
    linkElement.rel = 'stylesheet';
    document.head.appendChild(linkElement);
  }
  
  // Avoid reloading the same font
  if (linkElement.dataset.loaded === fontOption.google) return;
  
  // Load the new font
  linkElement.href = `https://fonts.googleapis.com/css2?family=${fontOption.google}&display=swap`;
  linkElement.dataset.loaded = fontOption.google;
}

export function applyFontSize(fontSize: number): void {
  if (fontSize === undefined || fontSize === null || isNaN(fontSize)) {
    return; // Guard against invalid values
  }
  
  const root = document.documentElement;
  root.style.setProperty('--font-size', `${fontSize}px`);
}

export function applyAccentColor(color: string): void {
  const root = document.documentElement;
  
  // Convert hex to HSL for CSS variables
  const hex = color.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16) / 255;
  const g = parseInt(hex.substring(2, 4), 16) / 255;
  const b = parseInt(hex.substring(4, 6), 16) / 255;
  
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  
  const hsl = `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
  root.style.setProperty('--primary', hsl);
  root.style.setProperty('--glow', hsl);
}
