import html2pdf from 'html2pdf.js';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import * as XLSX from 'xlsx';

/**
 * Export a note as plain text (.txt)
 */
export async function exportToTxt(content: string, title: string): Promise<void> {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = content;
  const plainText = tempDiv.innerText || tempDiv.textContent || '';
  
  const blob = new Blob([plainText], { type: 'text/plain' });
  downloadBlob(blob, `${title}-${Date.now()}.txt`);
}

/**
 * Export a note as PDF (.pdf)
 */
export async function exportToPdf(content: string, title: string): Promise<void> {
  const element = document.createElement('div');
  element.innerHTML = `
    <div style="padding: 40px; font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto;">
      <h1 style="margin-bottom: 20px; color: #1a1a1a;">${title}</h1>
      <div style="line-height: 1.6; color: #333;">
        ${content}
      </div>
      <div style="margin-top: 60px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #888; text-align: center;">
        Exported from Lumina
      </div>
    </div>
  `;
  
  const opt = {
    margin: 0.5,
    filename: `${title}-${Date.now()}.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2, useCORS: true },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
  };
  
  await html2pdf().set(opt).from(element).save();
}

/**
 * Export a note as Word document (.docx)
 * Converts HTML content to DOCX using the docx library
 */
export async function exportToDocx(content: string, title: string): Promise<void> {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = content;
  
  const paragraphs: Paragraph[] = [];
  
  paragraphs.push(
    new Paragraph({
      text: title,
      heading: HeadingLevel.HEADING_1,
      spacing: { after: 200 },
    })
  );
  
  const processNode = (node: Node): Paragraph | null => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent?.trim();
      if (text) {
        return new Paragraph({
          children: [new TextRun(text)],
          spacing: { after: 100 },
        });
      }
      return null;
    }
    
    if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as HTMLElement;
      const text = element.innerText || element.textContent || '';
      
      if (!text.trim()) return null;
      
      const tagName = element.tagName.toLowerCase();
      
      if (tagName === 'h1') {
        return new Paragraph({
          text,
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 200, after: 100 },
        });
      } else if (tagName === 'h2') {
        return new Paragraph({
          text,
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 },
        });
      } else if (tagName === 'h3') {
        return new Paragraph({
          text,
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 150, after: 100 },
        });
      } else if (tagName === 'p') {
        return new Paragraph({
          children: [new TextRun(text)],
          spacing: { after: 100 },
        });
      } else if (tagName === 'li') {
        const isChecked = element.getAttribute('data-checked');
        const prefix = isChecked === 'true' ? '☑ ' : isChecked === 'false' ? '☐ ' : '• ';
        return new Paragraph({
          children: [new TextRun(prefix + text)],
          spacing: { after: 50 },
        });
      }
    }
    
    return null;
  };
  
  const traverse = (node: Node) => {
    const para = processNode(node);
    if (para) paragraphs.push(para);
    
    node.childNodes.forEach(child => {
      if (child.nodeType === Node.ELEMENT_NODE) {
        const tagName = (child as HTMLElement).tagName.toLowerCase();
        if (['h1', 'h2', 'h3', 'p', 'li'].includes(tagName)) {
          const para = processNode(child);
          if (para) paragraphs.push(para);
        } else {
          traverse(child);
        }
      }
    });
  };
  
  traverse(tempDiv);
  
  paragraphs.push(
    new Paragraph({
      children: [
        new TextRun({
          text: 'Exported from Lumina',
          size: 18,
          color: '888888',
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { before: 400 },
      border: {
        top: { color: 'CCCCCC', space: 1, style: 'single', size: 6 },
      },
    })
  );
  
  const doc = new Document({
    sections: [{
      properties: {},
      children: paragraphs,
    }],
  });
  
  const blob = await Packer.toBlob(doc);
  downloadBlob(blob, `${title}-${Date.now()}.docx`);
}

/**
 * Export a note as Excel spreadsheet (.xlsx)
 * Extracts tables from HTML or creates a simple text sheet
 */
export async function exportToXlsx(content: string, title: string): Promise<void> {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = content;
  
  const tables = tempDiv.querySelectorAll('table');
  const workbook = XLSX.utils.book_new();
  
  if (tables.length > 0) {
    tables.forEach((table, index) => {
      const worksheet = XLSX.utils.table_to_sheet(table);
      const sheetName = `Table ${index + 1}`;
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    });
  } else {
    const plainText = tempDiv.innerText || tempDiv.textContent || '';
    const lines = plainText.split('\n').filter(line => line.trim());
    const data = lines.map(line => [line]);
    
    const worksheet = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Content');
  }
  
  XLSX.writeFile(workbook, `${title}-${Date.now()}.xlsx`);
}

/**
 * Export a note as self-contained HTML (.html)
 */
export async function exportToHtml(content: string, title: string): Promise<void> {
  const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      padding: 2rem;
      max-width: 800px;
      margin: 0 auto;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    .container {
      background: white;
      border-radius: 16px;
      padding: 3rem;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    }
    h1 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      color: #1a1a1a;
      border-bottom: 3px solid #667eea;
      padding-bottom: 0.5rem;
    }
    .content {
      color: #333;
      font-size: 1.1rem;
    }
    .content h2 {
      margin-top: 2rem;
      margin-bottom: 1rem;
      color: #667eea;
    }
    .content p {
      margin-bottom: 1rem;
    }
    .content ul, .content ol {
      margin-left: 1.5rem;
      margin-bottom: 1rem;
    }
    .content ul[data-type="taskList"] {
      list-style: none;
      margin-left: 0;
    }
    .content li[data-checked="true"]::before {
      content: "✓ ";
      color: #10b981;
      font-weight: bold;
      margin-right: 0.5rem;
    }
    .content li[data-checked="false"]::before {
      content: "○ ";
      color: #d1d5db;
      font-weight: bold;
      margin-right: 0.5rem;
    }
    .footer {
      margin-top: 3rem;
      padding-top: 1.5rem;
      border-top: 1px solid #e5e7eb;
      text-align: center;
      color: #9ca3af;
      font-size: 0.875rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>${title}</h1>
    <div class="content">
      ${content}
    </div>
    <div class="footer">
      Exported from Lumina — Your thoughts, beautifully kept
    </div>
  </div>
</body>
</html>
  `.trim();

  const blob = new Blob([htmlContent], { type: 'text/html' });
  downloadBlob(blob, `${title}-${Date.now()}.html`);
}

/**
 * Helper function to trigger file download
 */
function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Export format options
 */
export const EXPORT_FORMATS = [
  { value: 'txt', label: 'Plain Text (.txt)', icon: 'FileText' },
  { value: 'html', label: 'HTML Document (.html)', icon: 'Code' },
  { value: 'pdf', label: 'PDF Document (.pdf)', icon: 'FileImage' },
  { value: 'docx', label: 'Word Document (.docx)', icon: 'FileType' },
  { value: 'xlsx', label: 'Excel Spreadsheet (.xlsx)', icon: 'Table' },
] as const;

export type ExportFormat = typeof EXPORT_FORMATS[number]['value'];

/**
 * Main export function that delegates to format-specific handlers
 */
export async function exportNote(
  format: ExportFormat,
  content: string,
  title: string
): Promise<void> {
  switch (format) {
    case 'txt':
      return exportToTxt(content, title);
    case 'html':
      return exportToHtml(content, title);
    case 'pdf':
      return exportToPdf(content, title);
    case 'docx':
      return exportToDocx(content, title);
    case 'xlsx':
      return exportToXlsx(content, title);
    default:
      throw new Error(`Unsupported export format: ${format}`);
  }
}
