# Lumina Design Guidelines
## A Luminous Note-Taking Sanctuary

### Design Philosophy

**Reference Approach**: Draw inspiration from Notion's clarity, Bear's elegant simplicity, Linear's refined typography, and Apple Notes' distraction-free focus. The app should feel like a quiet, well-lit room—calm, spacious, and reverent toward the user's thoughts.

**Core Metaphor**: Light as clarity. Every interaction should feel luminous—soft glows, gentle transitions, and breathing space. Avoid harsh edges or aggressive elements.

### Typography System

**Primary Font Stack**: 
- Default: Inter (400, 600) for UI and body text—clean, readable, modern
- Soul: Cormorant Garamond (400, 600) for serif lovers—elegant, contemplative
- Precision: JetBrains Mono (400, 600) for code/technical notes—focused, structured

**Type Scale**:
- H1 (App title/headers): 24px, weight 600, letter-spacing -0.5px
- H2 (Section headers): 18px, weight 600
- Body (Editor content): 16px, weight 400, line-height 1.6
- UI labels: 14px, weight 400
- Small text (timestamps, hints): 13px, weight 400, opacity 0.7

**Editor-Specific Typography**:
- Generous line-height (1.7-1.8) for comfortable reading
- Maximum width constraint: 800px for optimal readability
- Left-aligned for natural text flow
- Subtle text anti-aliasing for smoothness

### Layout & Spacing System

**Spatial Units**: Use Tailwind spacing in multiples of 4—primarily 4, 8, 12, 16, 24, 32, 48 for consistency.

**App Architecture**:
```
┌─────────────────────────────────────┐
│  Header (60px fixed)                │
├──────────┬──────────────────────────┤
│ Sidebar  │  Editor Canvas           │
│ (280px)  │  (fluid, max-w-3xl)      │
│          │                           │
│ Note     │  Rich Text Editor         │
│ List     │  + PDF/PPTX Viewer        │
│          │                           │
└──────────┴──────────────────────────┘
```

**Header Bar**:
- Height: 60px fixed, sticky top
- Padding: px-6
- Elements: Logo (left) → Controls cluster (right)
- Border-bottom: 1px subtle divider
- Background: Semi-transparent with backdrop blur for depth

**Sidebar**:
- Width: 280px fixed on desktop, hidden on mobile (<768px)
- Padding: p-4
- Note cards: mb-3 spacing
- Scrollable overflow with custom scrollbar (thin, subtle)

**Editor Container**:
- Max-width: 800px (prose width)
- Padding: p-6 on mobile, p-12 on desktop
- Centered with mx-auto
- Minimum height to prevent jumping

**Note Cards (Sidebar)**:
- Padding: p-4
- Margin-bottom: mb-3
- Border-radius: 12px (rounded-xl)
- Single line with ellipsis overflow
- Subtle elevation: shadow-sm
- Active state: border-l-3 accent indicator

### Component Design Patterns

**Glass-Morphism Treatment**:
- Semi-transparent backgrounds with backdrop-filter: blur(12px)
- Soft inner shadows: inset 0 0 0 1px rgba(border)
- Subtle outer glow on hover/focus states
- Border-radius: 12-16px consistently

**Editor Panel**:
- Background: Semi-transparent surface
- Border-radius: 16px
- Padding: p-6
- Min-height: 400px
- Focus state: Soft glow (0 0 0 2px accent with low opacity)
- Cursor glow effect: Subtle highlight follows text cursor

**File Viewer (PDF/PPTX)**:
- Appears below editor when file attached
- Same glass treatment as editor
- Navigation controls: Centered, minimal buttons
- Canvas/content: Centered, max-width constrained
- Close button: Top-right corner, subtle

**Control Buttons**:
- Size: 36px × 36px (icon buttons)
- Border-radius: 8px
- Minimal border: 1px subtle
- Hover: Lift effect (translateY -1px) + subtle shadow
- Active: Scale 0.95
- Icon-only for header, text optional for primary actions

**Theme/Font Selectors**:
- Dropdown style with 8px border-radius
- Padding: px-3 py-2
- Border: 1px subtle
- Hover: Slight glow
- Options: Clear hierarchy, generous padding

**Color Picker (Accent)**:
- 32px × 32px circular swatch
- Border: 2px white/dark with shadow
- Opens native color picker on click

### Empty State Experience

**"First Spark" Screen**:
- Full viewport centered layout
- Spark emoji: 48px size with pulse animation (2s infinite)
- Tagline: "Light begins with a single thought" (20px, centered)
- CTA button: "Begin" with soft glow, rounded-xl, px-8 py-3
- Gentle fade-in animation on load (0.6s ease)

**Animation**:
```
Pulse: scale(1) → scale(1.15) → scale(1)
Opacity: 1 → 0.6 → 1
Duration: 2s infinite ease-in-out
```

### Interaction Patterns

**Note Creation/Selection**:
- Click "+" button → Instant new note, focus editor
- Click note card → Smooth transition, content fade-in
- Auto-save: Silent, no loading indicators (feels instant)

**File Attachment**:
- Click 📄 button → Native file picker
- Upload → Processing indicator → Viewer appears below
- Page navigation (PDF): Prev/Next buttons, centered
- Close viewer → Smooth collapse animation

**Export Flow**:
- Click export → Download triggers immediately
- Branded footer in exported HTML
- No modal/confirmation—just works

**Breathe Mode** (Press ESC):
- Full-screen overlay: Semi-transparent dark scrim
- Centered breathing circle: 120px, pulsing with guidance text
- Auto-dismiss after 8 seconds
- Fade in/out: 0.3s ease

### Micro-Interactions

**Cursor Glow**: Subtle highlight (2px accent shadow) follows typing cursor—barely perceptible but present

**Card Hover**: 
- Note cards lift slightly (translateY -2px)
- Shadow intensifies
- Glow appears (accent with low opacity)
- Transition: 200ms ease

**Focus States**:
- Editor: 2px soft glow ring
- Inputs: Same glow treatment
- No harsh outlines

**Loading States**: 
- Minimal—prefer skeleton text or fade-in
- No spinners unless file processing >1s

### Responsive Behavior

**Desktop (>1024px)**:
- Sidebar visible, full layout
- Editor max-width 800px, generous padding

**Tablet (768-1024px)**:
- Sidebar toggleable with hamburger menu
- Editor slightly reduced padding

**Mobile (<768px)**:
- Sidebar hidden by default (toggle menu)
- Full-width editor with reduced padding (p-4)
- Note list as bottom sheet or full-screen overlay
- Controls stack vertically in header if needed

### Accessibility & Polish

- Keyboard shortcuts visible on hover (tooltips)
- Focus indicators: Clear but soft (glow, not harsh outline)
- Contrast ratios: WCAG AA minimum for all text
- Touch targets: Minimum 44px for mobile
- Smooth transitions: 200-300ms for most interactions
- Reduced motion support: Disable animations if preferred

### Images

**No images required**: This is a pure web app interface. The empty state uses emoji (✨ spark) as symbolic illustration. The design relies on typography, spacing, and subtle visual effects rather than photographic or illustrative imagery.

### Brand Expression

**Minimal branding**: "Lumina" wordmark in header (H1 treatment). No logo needed—the luminous, glass-like UI is the brand identity.

**Footer/Credits**: Export watermark only—"Exported from Lumina — your thoughts, beautifully kept."