# Lumina - Your thoughts, beautifully kept

A privacy-first, offline-capable note-taking sanctuary for solo thinkers.

## Overview

Lumina is a 100% open-source, zero-login, web-based note-taking app designed exclusively for solo users who value privacy, beauty, and cognitive calm. All data stays in the browser using IndexedDB - no backend required for core functionality.

## Core Principles

- **Zero Hassle**: No signup, no onboarding, no paywalls
- **Radical Privacy**: All data stays in browser (IndexedDB)
- **Offline-First**: Fully functional without internet
- **Solo-First**: No collaboration, just you and your thoughts
- **Open Source (MIT)**: Transparent, auditable, forever free

## Features

### Notes
- Rich text editing with Tiptap
- Markdown support
- To-do lists with checkboxes
- Auto-save to IndexedDB
- Automatic title extraction

### Files
- Upload & view PDF documents with page navigation (PDF.js)
- Upload & download PowerPoint presentations (preview coming soon)
- Files stored as blobs in IndexedDB per note

### Customization
- Light / Dark / System theme modes
- Custom accent color picker
- Font size selector (14px to 24px with 5 presets)
- Expanded font library with 12 Google Fonts:
  - **Sans-serif**: Inter (Clarity), Roboto (Modern), Open Sans (Friendly), Lato (Light), Montserrat (Bold), Poppins (Geometric), Source Sans 3 (Crisp)
  - **Serif**: Cormorant Garamond (Soul), Playfair Display (Royal), Lora (Balanced), Merriweather (Classic)
  - **Monospace**: JetBrains Mono (Precision)

### Export & Share
- Multi-format export with dropdown menu:
  - **Plain Text (.txt)** - Clean text extraction
  - **HTML Document (.html)** - Beautiful self-contained pages
  - **PDF Document (.pdf)** - Professional formatted PDFs (html2pdf.js)
  - **Word Document (.docx)** - Editable DOCX files (docx library)
  - **Excel Spreadsheet (.xlsx)** - Table extraction or text sheets (SheetJS)
- Share notes via public link (localStorage-based)
- All exports include branded footer: "Exported from Lumina"
- Files named with note title + timestamp

### Wellbeing
- Breathe Mode (press ESC) - guided breathing overlay
- Distraction-free writing environment
- Poetic empty state: "Light begins with a single thought"
- Glass-morphism UI with soft glow effects

### AI (Optional)
- DeepSeek-powered assistant via secure backend proxy
- API key stored in Replit Secrets (never exposed to frontend)
- Summarize or improve notes

## Technical Stack

### Frontend
- React + TypeScript
- Wouter for routing
- TanStack Query for state management
- Tiptap for rich text editing
- IndexedDB for client-side storage
- Tailwind CSS for styling
- Shadcn/ui components

### Backend (AI Only)
- Express.js server
- AI proxy endpoint for DeepSeek API
- CORS and JSON middleware
- Environment variable handling

### External Libraries (CDN)
- PDF.js for PDF rendering
- Mammoth.js for PowerPoint conversion
- Tiptap extensions for rich text

## Architecture

```
┌─────────────────────────────────────┐
│  Header (sticky, glass effect)      │
├──────────┬──────────────────────────┤
│ Sidebar  │  Editor Canvas           │
│ (280px)  │  (fluid, max-w-3xl)      │
│          │                           │
│ Note     │  Rich Text Editor         │
│ List     │  + PDF/PPTX Viewer        │
│          │                           │
└──────────┴──────────────────────────┘
```

## Color System

Lumina uses a luminous color palette with glass-morphism effects:

- Light mode: Pure white background with subtle grays
- Dark mode: Deep navy background with soft contrast
- Accent: Customizable (default: indigo #6366f1)
- Glow effects: Dynamic based on accent color

## Data Storage

All notes are stored in browser's IndexedDB:

```typescript
interface Note {
  id: string;
  content: string; // HTML from Tiptap
  title: string; // Auto-extracted
  updatedAt: number; // Timestamp
  pdf?: Blob; // Optional PDF attachment
  pptx?: Blob; // Optional PowerPoint
}
```

User settings stored in localStorage:
```typescript
interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  accentColor: string;
  fontFamily: 'inter' | 'roboto' | 'opensans' | 'lato' | 'montserrat' | 'poppins' | 'sourcesans3' | 'cormorant' | 'playfair' | 'lora' | 'merriweather' | 'jetbrains';
  fontSize: number; // 14px to 24px
}
```

## Brand Identity

- **Name**: Lumina (from "lumen" - unit of light)
- **Tagline**: "Your thoughts, beautifully kept"
- **Ethos**: A digital sanctuary where ideas are treated with reverence

## Development

The app follows a schema-first development approach:
1. Define data models in `shared/schema.ts`
2. Build React components with design system
3. Implement IndexedDB storage
4. Add backend AI proxy (optional)

## Design Philosophy

**Light as Metaphor**: Notes appear as glowing "light panels" with glass-morphism. Every interaction feels luminous - soft glows, gentle transitions, breathing space.

**No Harsh Edges**: Border radius of 12-16px consistently. Subtle shadows and inner glows instead of hard borders.

**Typography as Mood**: Three carefully selected fonts that reflect different emotional contexts - clarity, soul, precision.

**Poetic Interactions**: Empty state poetry, breathing animations, spark pulse effects.

## Recent Changes

- **November 1, 2025**
  - **Documentation**: Added comprehensive README.md covering all features, installation, usage, and technical architecture
- **October 28, 2025**
  - **Responsive Design**: Full mobile and tablet support implemented
    - Mobile sidebar with slide-in drawer using Sheet component
    - Hamburger menu button for mobile/tablet navigation
    - Responsive breakpoints: Mobile (<768px), Tablet (768-1023px), Desktop (≥1024px)
    - Progressive UI: essential features always visible, advanced features hidden on small screens
    - Responsive header: font selectors hidden on small screens, buttons adapt to viewport
    - Responsive editor: padding adjusts from p-3 (mobile) to p-6 (desktop)
    - Touch-friendly interface with WCAG-compliant 44x44px touch targets
    - All responsive tests passing with validated touch accessibility
- **October 27, 2025**
  - **AI Integration**: DeepSeek API securely configured via Replit Secrets
  - **Brand Enhancement**: Lumina logo now has animated glow effect (pulsing + gradient shift)
  - **CRITICAL Security Fixes**:
    - ✅ Fixed XSS vulnerability in file viewer (removed dangerouslySetInnerHTML)
    - ✅ Sanitized error messages in AI proxy (no internal details exposed)
    - ✅ Sanitized server error responses (prevent stack trace leaks)
    - ✅ Added input validation to AI endpoint (10k char limit, model whitelist)
    - ✅ Added DoS protection with prompt length limits
  - **Typography Overhaul**: Expanded to 29 fonts (7 system + 22 Google) with 6 categories
  - **Microsoft Office-level font sizes**: 17 options (8px-72px) with working CSS implementation
  - **Dynamic font loading**: System fonts instant, Google Fonts load on demand
  - **Grouped font selector**: Category-organized dropdown (System, Sans-serif, Serif, Monospace, Script, Display)
  - **Bug fixes**: Font size CSS override (moved outside @layer), theme selector duplicate icons
  - **Multi-format export**: TXT, HTML, PDF, DOCX, XLSX with browser-compatible libraries
  - **Rename notes**: Inline edit dialog with validation and persistence
  - **Font persistence**: Full settings merge to localStorage
  - Added validation guards for font size to prevent NaN issues
- **Initial Release**
  - Created complete data schema for notes and settings
  - Built IndexedDB storage utilities
  - Implemented theme system with light/dark/system modes
  - Created all React components with glass-morphism aesthetic
  - Integrated Tiptap rich text editor
  - Added PDF and PowerPoint viewer components
  - Implemented file attachment system
  - Created export and share functionality
  - Added Breathe Mode overlay (ESC key)
  - Configured luminous color palette in Tailwind

## User Preferences

- Privacy-first architecture (no tracking, no analytics)
- Offline-first design (works without internet)
- Beautiful, calm UI with soft interactions
- Professional design quality expected
